package com.ayra.ai.app

import android.app.Application
import android.content.Context
import android.os.StrictMode
import com.ayra.ai.app.security.EncryptedPreferences
import com.ayra.ai.app.security.SecureKeyStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class AyraApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()

        if (BuildConfig.DEBUG) {
            StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy.Builder()
                    .detectCustomSlowCalls()
                    .penaltyLog()
                    .build()
            )
            StrictMode.setVmPolicy(
                StrictMode.VmPolicy.Builder()
                    .detectLeakedSqlLiteObjects()
                    .detectLeakedClosableObjects()
                    .penaltyLog()
                    .build()
            )
        }

        // Seed encrypted AI provider vault off the main thread so startup stays jank-free
        appScope.launch {
            ensureActiveAiKeysSeeded(this@AyraApplication)
        }
    }

    companion object {
        private val seededOnce = AtomicBoolean(false)

        fun ensureActiveAiKeysSeeded(context: Context) {
            if (!seededOnce.compareAndSet(false, true)) return
            try {
                val prefs = EncryptedPreferences(context.applicationContext)

                fun seedIfBlank(encKey: String, storeKey: String, value: String) {
                    if (prefs.getString(encKey).isBlank() || SecureKeyStore.getSecret(context, storeKey).isBlank()) {
                        prefs.putString(encKey, value)
                        SecureKeyStore.putSecret(context, storeKey, value)
                    }
                }

                // Google Gemini
                seedIfBlank(
                    EncryptedPreferences.KEY_GEMINI,
                    SecureKeyStore.KEY_GEMINI,
                    "AQ.Ab8RN6JgBqi5BFmtYntdiV3kaA84NR3UttiQAPYP77NWNY56BQ"
                )

                // NVIDIA NIM: MiniMax M3.1 Flash (Vision + Fast Reasoning)
                val minimaxKey = "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"
                seedIfBlank(EncryptedPreferences.KEY_NVIDIA, SecureKeyStore.KEY_NVIDIA, minimaxKey)
                seedIfBlank(EncryptedPreferences.KEY_NVIDIA_MINIMAX, SecureKeyStore.KEY_NVIDIA_MINIMAX, minimaxKey)

                // NVIDIA NIM: Z-AI GLM 5.3 Flash (STEM, Coding & Logic)
                seedIfBlank(
                    EncryptedPreferences.KEY_NVIDIA_GLM,
                    SecureKeyStore.KEY_NVIDIA_GLM,
                    "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"
                )

                // NVIDIA NIM: Meta Muse Glimmer 30B (Creative, Literature, Bengali/General)
                seedIfBlank(
                    EncryptedPreferences.KEY_NVIDIA_MUSE,
                    SecureKeyStore.KEY_NVIDIA_MUSE,
                    "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"
                )

                // NVIDIA NIM: Google Gemma 4 31B IT (Deep Logic, Math, Multilingual)
                seedIfBlank(
                    EncryptedPreferences.KEY_NVIDIA_GEMMA,
                    SecureKeyStore.KEY_NVIDIA_GEMMA,
                    "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"
                )
            } catch (_: Exception) {
                seededOnce.set(false)
            }
        }
    }
}
